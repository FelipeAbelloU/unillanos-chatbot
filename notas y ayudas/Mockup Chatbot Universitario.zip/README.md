
  # Chatbot Universitario

  This is a code bundle for Chatbot Universitario. The original project is available at https://www.figma.com/design/6wQztAdXELhwQAWeP9cEkY/Chatbot-Universitario.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  