import React, { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Send, X, Minus, Moon, Sun } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTheme } from './ThemeContext';
import logoGarza from 'figma:asset/c8ff85738edffb961ce988d00e07b4a51527497a.png';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export function FloatingChat() {
  const { isDark, toggleTheme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const simulateResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('horario') || lowerMessage.includes('hora')) {
      return 'Los horarios de clase se publican al inicio de cada semestre en el portal estudiantil. Las clases matutinas son de 7:00 AM a 2:00 PM y las vespertinas de 2:00 PM a 9:00 PM.';
    } else if (lowerMessage.includes('inscri') || lowerMessage.includes('matrícula')) {
      return 'El periodo de inscripción se realiza dos veces al año: en enero para el semestre de primavera y en julio para el semestre de otoño.';
    } else if (lowerMessage.includes('beca') || lowerMessage.includes('apoyo')) {
      return 'La universidad ofrece varios tipos de becas: académicas (promedio mayor a 90), deportivas, culturales y de necesidad económica. Las solicitudes se realizan durante el primer mes de cada semestre.';
    } else if (lowerMessage.includes('examen') || lowerMessage.includes('evaluación')) {
      return 'El sistema de evaluación incluye: exámenes parciales (40%), proyectos y tareas (30%), examen final (30%). Se requiere mínimo 70 puntos para aprobar.';
    } else if (lowerMessage.includes('biblioteca') || lowerMessage.includes('libro')) {
      return 'La biblioteca universitaria está abierta de lunes a viernes de 7:00 AM a 9:00 PM y sábados de 9:00 AM a 2:00 PM. Puedes solicitar préstamos de libros por 15 días renovables.';
    } else if (lowerMessage.includes('titulación') || lowerMessage.includes('título')) {
      return 'Para obtener el título profesional debes: completar el 100% de los créditos, realizar servicio social (480 horas), y elegir una opción de titulación.';
    } else {
      return '¡Hola! Soy el asistente virtual de la universidad. Puedo ayudarte con información sobre: reglamentos académicos, horarios, inscripciones, becas, evaluaciones, biblioteca y titulación. ¿Qué necesitas saber?';
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: simulateResponse(inputMessage),
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1000);
  };

  return (
    <>
      {/* Floating Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-6 right-6 w-16 h-16 bg-white hover:shadow-xl rounded-full shadow-lg flex items-center justify-center z-50 transition-all p-2 border-2 border-red-600"
          >
            <img src={logoGarza} alt="Chat" className="w-full h-full" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ 
              opacity: 1, 
              y: 0, 
              scale: 1,
              height: isMinimized ? 'auto' : '600px'
            }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className={`fixed bottom-6 right-6 w-96 ${isDark ? 'bg-neutral-950' : 'bg-white'} rounded-2xl shadow-2xl flex flex-col overflow-hidden z-50`}
          >
            {/* Header */}
            <div className="bg-red-600 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center p-1.5">
                  <img src={logoGarza} alt="Logo" className="w-full h-full" />
                </div>
                <div>
                  <p>Asistente Universitario</p>
                  <p className="text-xs text-red-100">En línea</p>
                </div>
              </div>
              <div className="flex gap-1">
                <button
                  onClick={toggleTheme}
                  className="w-8 h-8 hover:bg-white/20 rounded-lg flex items-center justify-center transition-colors"
                >
                  {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                </button>
                <button
                  onClick={() => setIsMinimized(!isMinimized)}
                  className="w-8 h-8 hover:bg-white/20 rounded-lg flex items-center justify-center transition-colors"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  className="w-8 h-8 hover:bg-white/20 rounded-lg flex items-center justify-center transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Messages */}
            {!isMinimized && (
              <>
                <ScrollArea className={`flex-1 p-4 ${isDark ? 'bg-neutral-900' : 'bg-gray-50'}`}>
                  <div className="space-y-4">
                    {!messages.length && (
                      <div className="text-center py-8">
                        <div className="w-14 h-14 mx-auto mb-3 bg-white rounded-full flex items-center justify-center p-2">
                          <img src={logoGarza} alt="Logo" className="w-full h-full" />
                        </div>
                        <p className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>¡Hola! ¿En qué puedo ayudarte hoy?</p>
                      </div>
                    )}
                    
                    {messages.map(message => (
                      <div
                        key={message.id}
                        className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[80%] rounded-2xl px-3 py-2 ${
                            message.role === 'user'
                              ? 'bg-red-600 text-white'
                              : isDark ? 'bg-neutral-800 text-white border border-neutral-700' : 'bg-white border'
                          }`}
                        >
                          <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                        </div>
                      </div>
                    ))}

                    {isTyping && (
                      <div className="flex justify-start">
                        <div className={`rounded-2xl px-3 py-2 ${isDark ? 'bg-neutral-800 border border-neutral-700' : 'bg-white border'}`}>
                          <div className="flex gap-1">
                            <span className={`w-2 h-2 ${isDark ? 'bg-gray-400' : 'bg-gray-400'} rounded-full animate-bounce`}></span>
                            <span className={`w-2 h-2 ${isDark ? 'bg-gray-400' : 'bg-gray-400'} rounded-full animate-bounce`} style={{ animationDelay: '0.1s' }}></span>
                            <span className={`w-2 h-2 ${isDark ? 'bg-gray-400' : 'bg-gray-400'} rounded-full animate-bounce`} style={{ animationDelay: '0.2s' }}></span>
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>

                {/* Input */}
                <div className={`p-4 border-t ${isDark ? 'bg-neutral-950 border-neutral-800' : 'bg-white border-gray-200'}`}>
                  <div className="flex gap-2">
                    <Input
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="Escribe tu pregunta..."
                      className={`flex-1 text-sm ${isDark ? 'bg-neutral-800 border-neutral-700 text-white placeholder:text-gray-400' : ''}`}
                    />
                    <Button 
                      onClick={handleSendMessage} 
                      className="bg-red-600 hover:bg-red-700"
                      size="icon"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
