import React, { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Avatar } from './ui/avatar';
import { Send, Plus, MessageSquare, Moon, Sun } from 'lucide-react';
import { useTheme } from './ThemeContext';
import logoGarza from 'figma:asset/c8ff85738edffb961ce988d00e07b4a51527497a.png';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
}

export function FullScreenChat() {
  const { isDark, toggleTheme } = useTheme();
  const [conversations, setConversations] = useState<Conversation[]>([
    {
      id: '1',
      title: 'Reglamento de estudios',
      messages: [
        {
          id: '1',
          role: 'user',
          content: '¿Cuál es el reglamento de estudios?',
          timestamp: new Date(Date.now() - 3600000)
        },
        {
          id: '2',
          role: 'assistant',
          content: 'El Reglamento de Estudios de nuestra universidad establece las normas académicas que rigen la vida estudiantil. Los aspectos principales incluyen: asistencia mínima del 75%, sistema de calificación del 0-100, y requisitos de aprobación con nota mínima de 70 puntos.',
          timestamp: new Date(Date.now() - 3500000)
        }
      ],
      createdAt: new Date(Date.now() - 3600000)
    }
  ]);
  
  const [currentConversationId, setCurrentConversationId] = useState<string>('1');
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentConversation = conversations.find(c => c.id === currentConversationId);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [currentConversation?.messages]);

  const simulateResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('horario') || lowerMessage.includes('hora')) {
      return 'Los horarios de clase se publican al inicio de cada semestre en el portal estudiantil. Las clases matutinas son de 7:00 AM a 2:00 PM y las vespertinas de 2:00 PM a 9:00 PM. Puedes consultar tu horario específico en tu perfil académico.';
    } else if (lowerMessage.includes('inscri') || lowerMessage.includes('matrícula')) {
      return 'El periodo de inscripción se realiza dos veces al año: en enero para el semestre de primavera y en julio para el semestre de otoño. Los estudiantes de nuevo ingreso tienen prioridad, seguidos por estudiantes regulares según su promedio académico.';
    } else if (lowerMessage.includes('beca') || lowerMessage.includes('apoyo')) {
      return 'La universidad ofrece varios tipos de becas: académicas (promedio mayor a 90), deportivas, culturales y de necesidad económica. Las solicitudes se realizan durante el primer mes de cada semestre en el Departamento de Servicios Escolares.';
    } else if (lowerMessage.includes('examen') || lowerMessage.includes('evaluación')) {
      return 'El sistema de evaluación incluye: exámenes parciales (40%), proyectos y tareas (30%), examen final (30%). Se requiere mínimo 70 puntos para aprobar. Los exámenes extraordinarios están disponibles para quienes no aprueben en ordinario.';
    } else if (lowerMessage.includes('biblioteca') || lowerMessage.includes('libro')) {
      return 'La biblioteca universitaria está abierta de lunes a viernes de 7:00 AM a 9:00 PM y sábados de 9:00 AM a 2:00 PM. Puedes solicitar préstamos de libros por 15 días renovables. También contamos con bases de datos digitales accesibles con tu credencial estudiantil.';
    } else if (lowerMessage.includes('titulación') || lowerMessage.includes('título')) {
      return 'Para obtener el título profesional debes: completar el 100% de los créditos, realizar servicio social (480 horas), y elegir una opción de titulación (tesis, examen profesional, promedio destacado mayor a 95, o estudios de posgrado).';
    } else {
      return 'Gracias por tu pregunta. Como asistente virtual de la universidad, puedo ayudarte con información sobre: reglamentos académicos, horarios, inscripciones, becas, sistema de evaluación, biblioteca, titulación y más. ¿Sobre qué tema específico te gustaría saber?';
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || !currentConversation) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setConversations(prev => prev.map(conv => 
      conv.id === currentConversationId
        ? { ...conv, messages: [...conv.messages, userMessage] }
        : conv
    ));

    setInputMessage('');
    setIsTyping(true);

    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: simulateResponse(inputMessage),
        timestamp: new Date()
      };

      setConversations(prev => prev.map(conv => 
        conv.id === currentConversationId
          ? { ...conv, messages: [...conv.messages, assistantMessage] }
          : conv
      ));
      setIsTyping(false);
    }, 1000);
  };

  const createNewConversation = () => {
    const newConv: Conversation = {
      id: Date.now().toString(),
      title: 'Nueva conversación',
      messages: [],
      createdAt: new Date()
    };
    setConversations(prev => [newConv, ...prev]);
    setCurrentConversationId(newConv.id);
  };

  return (
    <div className={`flex h-screen ${isDark ? 'bg-neutral-950' : 'bg-white'}`}>
      {/* Sidebar */}
      <div className={`w-64 ${isDark ? 'bg-neutral-900' : 'bg-gray-100'} flex flex-col border-r ${isDark ? 'border-neutral-800' : 'border-gray-200'}`}>
        <div className="p-4">
          <Button 
            onClick={createNewConversation}
            className="w-full bg-red-600 text-white hover:bg-red-700 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Nueva conversación
          </Button>
        </div>

        <ScrollArea className="flex-1 px-2">
          <div className="space-y-1">
            {conversations.map(conv => (
              <button
                key={conv.id}
                onClick={() => setCurrentConversationId(conv.id)}
                className={`w-full text-left px-3 py-2 rounded-lg flex items-start gap-2 transition-colors ${
                  currentConversationId === conv.id 
                    ? isDark ? 'bg-neutral-800 text-white' : 'bg-gray-200 text-gray-900'
                    : isDark ? 'text-gray-300 hover:bg-neutral-800' : 'text-gray-700 hover:bg-gray-200'
                }`}
              >
                <MessageSquare className="w-4 h-4 mt-1 flex-shrink-0" />
                <span className="text-sm truncate">{conv.title}</span>
              </button>
            ))}
          </div>
        </ScrollArea>

        <div className={`p-4 border-t ${isDark ? 'border-neutral-800' : 'border-gray-200'}`}>
          <div className="flex items-center gap-3 mb-3">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isDark ? 'bg-white' : 'bg-white'} p-0.5`}>
              <img src={logoGarza} alt="Logo" className="w-full h-full" />
            </div>
            <div className="flex-1">
              <p className={`text-sm ${isDark ? 'text-white' : 'text-gray-900'}`}>Chatbot Universitario</p>
              <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>Universidad</p>
            </div>
          </div>
          <Button
            onClick={toggleTheme}
            variant="outline"
            size="sm"
            className="w-full"
          >
            {isDark ? <Sun className="w-4 h-4 mr-2" /> : <Moon className="w-4 h-4 mr-2" />}
            {isDark ? 'Modo claro' : 'Modo oscuro'}
          </Button>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className={`h-14 border-b ${isDark ? 'bg-neutral-900 border-neutral-800' : 'bg-white border-gray-200'} flex items-center px-6`}>
          <h1 className={isDark ? 'text-white' : 'text-gray-900'}>Chat Normativo Universitario</h1>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 p-6">
          <div className="max-w-3xl mx-auto space-y-6">
            {!currentConversation?.messages.length && (
              <div className="text-center py-12">
                <div className="w-20 h-20 mx-auto mb-4 bg-white rounded-full flex items-center justify-center p-2">
                  <img src={logoGarza} alt="Logo" className="w-full h-full" />
                </div>
                <h2 className={`mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>Bienvenido al Chatbot Universitario</h2>
                <p className={isDark ? 'text-gray-400' : 'text-gray-500'}>Pregúntame sobre información normativa, reglamentos, horarios, becas y más.</p>
              </div>
            )}
            
            {currentConversation?.messages.map(message => (
              <div
                key={message.id}
                className={`flex gap-4 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {message.role === 'assistant' && (
                  <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center flex-shrink-0 p-1">
                    <img src={logoGarza} alt="Logo" className="w-full h-full" />
                  </div>
                )}
                <div
                  className={`max-w-2xl rounded-2xl px-4 py-3 ${
                    message.role === 'user'
                      ? 'bg-red-600 text-white'
                      : isDark ? 'bg-neutral-800 border border-neutral-700 text-white' : 'bg-white border border-gray-200 text-gray-900'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
                {message.role === 'user' && (
                  <div className={`w-8 h-8 rounded-full ${isDark ? 'bg-neutral-800' : 'bg-gray-300'} flex items-center justify-center flex-shrink-0`}>
                    <span className={isDark ? 'text-white text-sm' : 'text-gray-700 text-sm'}>U</span>
                  </div>
                )}
              </div>
            ))}

            {isTyping && (
              <div className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center flex-shrink-0 p-1">
                  <img src={logoGarza} alt="Logo" className="w-full h-full" />
                </div>
                <div className={`rounded-2xl px-4 py-3 ${isDark ? 'bg-neutral-800 border border-neutral-700' : 'bg-white border border-gray-200'}`}>
                  <div className="flex gap-1">
                    <span className={`w-2 h-2 ${isDark ? 'bg-gray-500' : 'bg-gray-400'} rounded-full animate-bounce`}></span>
                    <span className={`w-2 h-2 ${isDark ? 'bg-gray-500' : 'bg-gray-400'} rounded-full animate-bounce`} style={{ animationDelay: '0.1s' }}></span>
                    <span className={`w-2 h-2 ${isDark ? 'bg-gray-500' : 'bg-gray-400'} rounded-full animate-bounce`} style={{ animationDelay: '0.2s' }}></span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Input */}
        <div className={`border-t ${isDark ? 'bg-neutral-900 border-neutral-800' : 'bg-white border-gray-200'} p-4`}>
          <div className="max-w-3xl mx-auto">
            <div className="flex gap-2">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Escribe tu pregunta sobre normativa universitaria..."
                className={`flex-1 ${isDark ? 'bg-neutral-800 border-neutral-700 text-white placeholder:text-gray-400' : ''}`}
              />
              <Button onClick={handleSendMessage} className="bg-red-600 hover:bg-red-700">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
