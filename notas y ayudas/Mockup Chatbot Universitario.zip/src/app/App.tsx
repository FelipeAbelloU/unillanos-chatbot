import React, { useState } from 'react';
import { FullScreenChat } from './components/FullScreenChat';
import { FloatingChat } from './components/FloatingChat';
import { ThemeProvider } from './components/ThemeContext';
import { Button } from './components/ui/button';
import { Monitor, MessageCircle } from 'lucide-react';
import logoGarza from 'figma:asset/c8ff85738edffb961ce988d00e07b4a51527497a.png';

export default function App() {
  const [viewMode, setViewMode] = useState<'selector' | 'fullscreen' | 'floating'>('selector');

  if (viewMode === 'fullscreen') {
    return (
      <ThemeProvider>
        <div className="relative">
          <FullScreenChat />
          <Button
            onClick={() => setViewMode('selector')}
            className="absolute top-4 right-4 z-50 bg-red-600 hover:bg-red-700"
          >
            Cambiar Vista
          </Button>
        </div>
      </ThemeProvider>
    );
  }

  if (viewMode === 'floating') {
    return (
      <ThemeProvider>
        <div className="min-h-screen bg-gradient-to-br from-red-50 to-gray-100 dark:from-neutral-950 dark:to-neutral-900">
          {/* Demo Page Content */}
          <div className="max-w-6xl mx-auto p-8">
            <header className="mb-12 text-center">
              <h1 className="mb-4 dark:text-white">Universidad Demo</h1>
              <p className="text-gray-600 dark:text-gray-400">Esta es una página de ejemplo. El chatbot flotante aparece en la esquina inferior derecha.</p>
            </header>

            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <div className="bg-white dark:bg-neutral-900 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-neutral-800">
                <h3 className="mb-3 dark:text-white">Información Académica</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  Accede a toda la información sobre programas académicos, reglamentos y normativas universitarias.
                </p>
                <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                  <li>• Reglamentos académicos</li>
                  <li>• Calendario escolar</li>
                  <li>• Horarios de clase</li>
                  <li>• Sistema de evaluación</li>
                </ul>
              </div>

              <div className="bg-white dark:bg-neutral-900 rounded-xl p-6 shadow-sm border border-gray-200 dark:border-neutral-800">
                <h3 className="mb-3 dark:text-white">Servicios Estudiantiles</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  Conoce los servicios disponibles para estudiantes de la universidad.
                </p>
                <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                  <li>• Biblioteca universitaria</li>
                  <li>• Becas y apoyos económicos</li>
                  <li>• Servicio social</li>
                  <li>• Proceso de titulación</li>
                </ul>
              </div>
            </div>

            <div className="bg-red-600 text-white rounded-xl p-8 text-center">
              <h2 className="mb-3">¿Tienes preguntas?</h2>
              <p className="mb-4 text-red-100">
                Usa nuestro asistente virtual en la esquina inferior derecha para obtener respuestas instantáneas sobre normativas y servicios universitarios.
              </p>
              <div className="inline-flex items-center gap-3 bg-white/20 px-4 py-2 rounded-lg">
                <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center p-1">
                  <img src={logoGarza} alt="Logo" className="w-full h-full" />
                </div>
                <span>Haz clic en el logo de la garza →</span>
              </div>
            </div>

            <Button
              onClick={() => setViewMode('selector')}
              className="mt-8 mx-auto block bg-red-600 hover:bg-red-700"
            >
              Cambiar Vista
            </Button>
          </div>

          <FloatingChat />
        </div>
      </ThemeProvider>
    );
  }

  // View Selector
  return (
    <div className="min-h-screen bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center p-8">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center p-3">
              <img src={logoGarza} alt="Logo" className="w-full h-full" />
            </div>
            <h1 className="text-white">Chatbot Universitario</h1>
          </div>
          <p className="text-red-100 text-lg">
            Selecciona el modo de visualización que prefieras
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Fullscreen Option */}
          <button
            onClick={() => setViewMode('fullscreen')}
            className="bg-white rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all hover:scale-105 text-left group"
          >
            <div className="w-16 h-16 bg-red-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-red-600 transition-colors">
              <Monitor className="w-8 h-8 text-red-600 group-hover:text-white transition-colors" />
            </div>
            <h2 className="mb-3 text-gray-900">Pantalla Completa</h2>
            <p className="text-gray-600 mb-4">
              Experiencia completa similar a ChatGPT con historial de conversaciones en el panel lateral izquierdo.
            </p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>✓ Vista de pantalla completa</li>
              <li>✓ Historial de conversaciones</li>
              <li>✓ Múltiples chats simultáneos</li>
              <li>✓ Modo oscuro/claro</li>
            </ul>
          </button>

          {/* Floating Option */}
          <button
            onClick={() => setViewMode('floating')}
            className="bg-white rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all hover:scale-105 text-left group"
          >
            <div className="w-16 h-16 bg-red-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-red-600 transition-colors">
              <MessageCircle className="w-8 h-8 text-red-600 group-hover:text-white transition-colors" />
            </div>
            <h2 className="mb-3 text-gray-900">Chat Flotante</h2>
            <p className="text-gray-600 mb-4">
              Widget de chat flotante en la esquina inferior derecha, disponible en cualquier página.
            </p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>✓ Botón flotante con logo de garza</li>
              <li>✓ Se despliega al hacer clic</li>
              <li>✓ No interrumpe la navegación</li>
              <li>✓ Modo oscuro/claro</li>
            </ul>
          </button>
        </div>

        <div className="mt-12 text-center">
          <p className="text-red-100 text-sm">
            Ambos chatbots incluyen respuestas automáticas sobre normativas universitarias, horarios, becas, evaluaciones y más.
          </p>
        </div>
      </div>
    </div>
  );
}
